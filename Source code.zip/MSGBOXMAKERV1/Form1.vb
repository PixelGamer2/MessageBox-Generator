﻿
Public Class Main

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub RichTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MsgBox("Paste the codes above on the places that are marked so the messagebox will be chained, by using 'Chan After' You need to place the line of code of your messagebox below the other to chain the messageboxes after each other no matter what" & vbCrLf & "" & vbCrLf & "I recommend using Notepad++ for coding this", vbOKOnly + vbInformation, "Help")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        example.Show()
    End Sub

    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked = True Then
            RichTextBox1.Enabled = True
            RichTextBox2.Enabled = False
            combobtnif.Enabled = False
            TextBox1.Enabled = False
            Label4.Enabled = False


        End If
    End Sub

    Private Sub RadioButton4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton4.CheckedChanged
        If RadioButton4.Checked = True Then
            RichTextBox1.Enabled = False
            RichTextBox2.Enabled = True
            combobtnif.Enabled = True
            TextBox1.Enabled = True
            Label4.Enabled = True
            combobtnif.Text = "OK"

            Dim varif
            varif = "x"
            varif = TextBox1.Text

            Dim combobtn
            combobtn = "vbOK"
            If combobtnif.Text = "OK" Then
                combobtn = "vbOK"
            End If
            If combobtnif.Text = "OK, Cancel" Then
                combobtn = "vbOKCancel"
            End If


            RichTextBox2.Text = ("If " + varif + " = " + combobtn + " Then" & vbCrLf & "    'Place some messagebox code here" & vbCrLf & "End if")
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        about.show()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        'Declare stuff
        Dim message
        message = textmsg.Text
        Dim title
        title = textttl.Text
        Dim variable
        variable = textvar.Text
        If textvar.Text = "" Then
            variable = "x"
        End If
        'If button radio button is checked then set value for button
        Dim btn
        btn = "0"
        If radiook.Checked = True Then
            btn = "0"
        End If
        If radiookcancel.Checked = True Then
            btn = "1"
        End If
        If radioyesno.Checked = True Then
            btn = "4"
        End If
        If radioyesnocancel.Checked = True Then
            btn = "3"
        End If
        If radioabort.Checked = True Then
            btn = "2"
        End If
        If radioretryignore.Checked = True Then
            btn = "5"
        End If


        'If icon radio button is checked then set value for icon
        Dim icon
        icon = "0"
        If radioiconone.Checked = True Then
            icon = "0"
        End If
        If radiox.Checked = True Then
            icon = "16"
        End If
        If radioexc.Checked = True Then
            icon = "48"
        End If
        If radioinfo.Checked = True Then
            icon = "64"
        End If
        If radioques.Checked = True Then
            icon = "32"
        End If

        'Messsagebox code as string
        Dim outputyay As String
        outputyay = variable + " = MsgBox (" + Chr(34) + message + Chr(34) + " ," + btn + "+" + icon + ", " + Chr(34) + title + Chr(34) + ")"
        outputtext.Text = outputyay

        donttouch.Text = outputtext.Text
        RichTextBox1.Text = outputtext.Text
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        On Error GoTo error2
        SaveFileDialog1.ShowDialog()
        donttouch.SaveFile(SaveFileDialog1.FileName, RichTextBoxStreamType.PlainText)
error2:
        Exit Sub
    End Sub

    Private Sub testbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles testbtn.Click
        'TESTINGBUTTON

        'Declare stuff
        Dim message
        message = textmsg.Text
        Dim title
        title = textttl.Text
        Dim variable
        variable = textvar.Text
        If textvar.Text = "" Then
            variable = "x"
        End If
        'If button radio button is checked then set value for button
        Dim btn
        btn = "0"
        If radiook.Checked = True Then
            btn = "0"
        End If
        If radiookcancel.Checked = True Then
            btn = "1"
        End If
        If radioyesno.Checked = True Then
            btn = "4"
        End If
        If radioyesnocancel.Checked = True Then
            btn = "3"
        End If
        If radioabort.Checked = True Then
            btn = "2"
        End If
        If radioretryignore.Checked = True Then
            btn = "5"
        End If

        'If icon radio button is checked then set value for icon
        Dim icon
        icon = "0"
        If radioiconone.Checked = True Then
            icon = "0"
        End If
        If radiox.Checked = True Then
            icon = "16"
        End If
        If radioexc.Checked = True Then
            icon = "48"
        End If
        If radioinfo.Checked = True Then
            icon = "64"
        End If
        If radioques.Checked = True Then
            icon = "32"
        End If

        variable = MsgBox(message, CInt(btn) + CInt(icon), title)
        
    End Sub

    Private Sub reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles reset.Click
        textmsg.Text = ""
        textttl.Text = ""
        textvar.Text = ""
        radiook.Checked = True
        radioiconone.Checked = True
        outputtext.Text = ""
        RichTextBox1.Text = ""
        RichTextBox2.Text = ""
        TextBox1.Text = ""
        RadioButton3.Checked = True


    End Sub

    Private Sub applybtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub



    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Dim combobtn
        combobtn = "vbOK"
        If combobtnif.Text = "OK" Then
            combobtn = "vbOK"
        End If
        If combobtnif.Text = "OK, Cancel" Then
            combobtn = "vbOKCancel"
        End If
        Dim varif
        varif = "x"
        varif = TextBox1.Text
        RichTextBox2.Text = ("If " + varif + " = " + combobtn + " Then" & vbCrLf & "    'Place some messagebox code here" & vbCrLf & "End if")
    End Sub

    Private Sub combobtnif_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles combobtnif.TextChanged
        Dim varif
        varif = "x"
        varif = TextBox1.Text

        Dim combobtn
        combobtn = "vbOK"
        If combobtnif.Text = "OK" Then
            combobtn = "vbOK"
        End If
        If combobtnif.Text = "OK, Cancel" Then
            combobtn = "vbOKCancel"
        End If


        RichTextBox2.Text = ("If " + varif + " = " + combobtn + " Then" & vbCrLf & "    'Place some messagebox code here" & vbCrLf & "End if")
    End Sub

End Class
