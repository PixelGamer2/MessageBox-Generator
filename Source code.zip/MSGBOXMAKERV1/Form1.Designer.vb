﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.textvar = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.textttl = New System.Windows.Forms.TextBox
        Me.textmsg = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.radioiconone = New System.Windows.Forms.RadioButton
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.combobtnif = New System.Windows.Forms.ComboBox
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox
        Me.RadioButton4 = New System.Windows.Forms.RadioButton
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.Button1 = New System.Windows.Forms.Button
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.radioretryignore = New System.Windows.Forms.RadioButton
        Me.radioabort = New System.Windows.Forms.RadioButton
        Me.radioyesnocancel = New System.Windows.Forms.RadioButton
        Me.radioyesno = New System.Windows.Forms.RadioButton
        Me.radiookcancel = New System.Windows.Forms.RadioButton
        Me.radiook = New System.Windows.Forms.RadioButton
        Me.outputtext = New System.Windows.Forms.TextBox
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.donttouch = New System.Windows.Forms.RichTextBox
        Me.testbtn = New System.Windows.Forms.Button
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.reset = New System.Windows.Forms.Button
        Me.radioques = New System.Windows.Forms.RadioButton
        Me.radioinfo = New System.Windows.Forms.RadioButton
        Me.radioexc = New System.Windows.Forms.RadioButton
        Me.radiox = New System.Windows.Forms.RadioButton
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1, 1)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.textvar)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.textttl)
        Me.GroupBox2.Controls.Add(Me.textmsg)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox2.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(163, 96)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "General"
        '
        'textvar
        '
        Me.textvar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textvar.Location = New System.Drawing.Point(54, 66)
        Me.textvar.Name = "textvar"
        Me.textvar.Size = New System.Drawing.Size(101, 20)
        Me.textvar.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label5.Location = New System.Drawing.Point(6, 70)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(48, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Variable:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label2.Location = New System.Drawing.Point(6, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Title:"
        '
        'textttl
        '
        Me.textttl.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textttl.Location = New System.Drawing.Point(54, 42)
        Me.textttl.Name = "textttl"
        Me.textttl.Size = New System.Drawing.Size(101, 20)
        Me.textttl.TabIndex = 2
        '
        'textmsg
        '
        Me.textmsg.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textmsg.Location = New System.Drawing.Point(54, 18)
        Me.textmsg.Name = "textmsg"
        Me.textmsg.Size = New System.Drawing.Size(101, 20)
        Me.textmsg.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label1.Location = New System.Drawing.Point(6, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Message:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.radioiconone)
        Me.GroupBox3.Controls.Add(Me.radioques)
        Me.GroupBox3.Controls.Add(Me.radioinfo)
        Me.GroupBox3.Controls.Add(Me.radioexc)
        Me.GroupBox3.Controls.Add(Me.radiox)
        Me.GroupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox3.Location = New System.Drawing.Point(175, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(54, 259)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Icon"
        '
        'radioiconone
        '
        Me.radioiconone.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.radioiconone.Appearance = System.Windows.Forms.Appearance.Button
        Me.radioiconone.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.radioiconone.Checked = True
        Me.radioiconone.Location = New System.Drawing.Point(6, 18)
        Me.radioiconone.Name = "radioiconone"
        Me.radioiconone.Size = New System.Drawing.Size(42, 42)
        Me.radioiconone.TabIndex = 4
        Me.radioiconone.TabStop = True
        Me.radioiconone.Text = "None"
        Me.radioiconone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radioiconone.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.TextBox1)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.combobtnif)
        Me.GroupBox4.Controls.Add(Me.RichTextBox2)
        Me.GroupBox4.Controls.Add(Me.RadioButton4)
        Me.GroupBox4.Controls.Add(Me.RadioButton3)
        Me.GroupBox4.Controls.Add(Me.Button1)
        Me.GroupBox4.Controls.Add(Me.RichTextBox1)
        Me.GroupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox4.Location = New System.Drawing.Point(235, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(354, 205)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Chain MessageBox (Use Notepad to Paste)"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(54, 126)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(78, 20)
        Me.TextBox1.TabIndex = 20
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label4.Location = New System.Drawing.Point(12, 130)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Variable"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label3.Location = New System.Drawing.Point(12, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Button(s)"
        '
        'combobtnif
        '
        Me.combobtnif.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.combobtnif.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.combobtnif.FormattingEnabled = True
        Me.combobtnif.IntegralHeight = False
        Me.combobtnif.ItemHeight = 13
        Me.combobtnif.Items.AddRange(New Object() {"OK", "OK, Cancel", "Yes, No", "Yes, No Cancel,", "Abort, Retry, Ignore", "Retry, Cancel"})
        Me.combobtnif.Location = New System.Drawing.Point(12, 96)
        Me.combobtnif.Name = "combobtnif"
        Me.combobtnif.Size = New System.Drawing.Size(121, 21)
        Me.combobtnif.TabIndex = 19
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(144, 48)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.ReadOnly = True
        Me.RichTextBox2.Size = New System.Drawing.Size(204, 120)
        Me.RichTextBox2.TabIndex = 18
        Me.RichTextBox2.Text = ""
        Me.RichTextBox2.WordWrap = False
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RadioButton4.Location = New System.Drawing.Point(6, 54)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(140, 18)
        Me.RadioButton4.TabIndex = 17
        Me.RadioButton4.Text = "Chain with If Statement"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Checked = True
        Me.RadioButton3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RadioButton3.Location = New System.Drawing.Point(6, 24)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(83, 18)
        Me.RadioButton3.TabIndex = 15
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "Chain After"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button1.Location = New System.Drawing.Point(270, 175)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 21
        Me.Button1.Text = "Help..."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(144, 18)
        Me.RichTextBox1.Multiline = False
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox1.Size = New System.Drawing.Size(204, 24)
        Me.RichTextBox1.TabIndex = 16
        Me.RichTextBox1.Text = ""
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button2.Location = New System.Drawing.Point(6, 271)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 23
        Me.Button2.Text = "Example..."
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.Controls.Add(Me.radioretryignore)
        Me.GroupBox5.Controls.Add(Me.radioabort)
        Me.GroupBox5.Controls.Add(Me.radioyesnocancel)
        Me.GroupBox5.Controls.Add(Me.radioyesno)
        Me.GroupBox5.Controls.Add(Me.radiookcancel)
        Me.GroupBox5.Controls.Add(Me.radiook)
        Me.GroupBox5.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox5.Location = New System.Drawing.Point(6, 102)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(163, 163)
        Me.GroupBox5.TabIndex = 2
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Button(s)"
        '
        'radioretryignore
        '
        Me.radioretryignore.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.radioretryignore.Appearance = System.Windows.Forms.Appearance.Button
        Me.radioretryignore.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.radioretryignore.Location = New System.Drawing.Point(85, 127)
        Me.radioretryignore.Name = "radioretryignore"
        Me.radioretryignore.Size = New System.Drawing.Size(72, 30)
        Me.radioretryignore.TabIndex = 14
        Me.radioretryignore.TabStop = True
        Me.radioretryignore.Text = "Retry, Cancel"
        Me.radioretryignore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radioretryignore.UseVisualStyleBackColor = True
        '
        'radioabort
        '
        Me.radioabort.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.radioabort.Appearance = System.Windows.Forms.Appearance.Button
        Me.radioabort.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.radioabort.Location = New System.Drawing.Point(6, 127)
        Me.radioabort.Name = "radioabort"
        Me.radioabort.Size = New System.Drawing.Size(73, 30)
        Me.radioabort.TabIndex = 13
        Me.radioabort.TabStop = True
        Me.radioabort.Text = "Abort, Retry, Ignore"
        Me.radioabort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radioabort.UseVisualStyleBackColor = True
        '
        'radioyesnocancel
        '
        Me.radioyesnocancel.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.radioyesnocancel.Appearance = System.Windows.Forms.Appearance.Button
        Me.radioyesnocancel.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.radioyesnocancel.Location = New System.Drawing.Point(85, 73)
        Me.radioyesnocancel.Name = "radioyesnocancel"
        Me.radioyesnocancel.Size = New System.Drawing.Size(72, 30)
        Me.radioyesnocancel.TabIndex = 12
        Me.radioyesnocancel.TabStop = True
        Me.radioyesnocancel.Text = "Yes, No, Cancel"
        Me.radioyesnocancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radioyesnocancel.UseVisualStyleBackColor = True
        '
        'radioyesno
        '
        Me.radioyesno.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.radioyesno.Appearance = System.Windows.Forms.Appearance.Button
        Me.radioyesno.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.radioyesno.Location = New System.Drawing.Point(6, 73)
        Me.radioyesno.Name = "radioyesno"
        Me.radioyesno.Size = New System.Drawing.Size(73, 30)
        Me.radioyesno.TabIndex = 11
        Me.radioyesno.TabStop = True
        Me.radioyesno.Text = "Yes, No"
        Me.radioyesno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radioyesno.UseVisualStyleBackColor = True
        '
        'radiookcancel
        '
        Me.radiookcancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.radiookcancel.Appearance = System.Windows.Forms.Appearance.Button
        Me.radiookcancel.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.radiookcancel.Location = New System.Drawing.Point(85, 18)
        Me.radiookcancel.Name = "radiookcancel"
        Me.radiookcancel.Size = New System.Drawing.Size(72, 30)
        Me.radiookcancel.TabIndex = 10
        Me.radiookcancel.TabStop = True
        Me.radiookcancel.Text = "OK, Cancel"
        Me.radiookcancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radiookcancel.UseVisualStyleBackColor = True
        '
        'radiook
        '
        Me.radiook.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.radiook.Appearance = System.Windows.Forms.Appearance.Button
        Me.radiook.Checked = True
        Me.radiook.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.radiook.Location = New System.Drawing.Point(6, 18)
        Me.radiook.Name = "radiook"
        Me.radiook.Size = New System.Drawing.Size(73, 30)
        Me.radiook.TabIndex = 9
        Me.radiook.TabStop = True
        Me.radiook.Text = "OK"
        Me.radiook.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radiook.UseVisualStyleBackColor = True
        '
        'outputtext
        '
        Me.outputtext.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.outputtext.Location = New System.Drawing.Point(48, 303)
        Me.outputtext.Name = "outputtext"
        Me.outputtext.ReadOnly = True
        Me.outputtext.Size = New System.Drawing.Size(463, 20)
        Me.outputtext.TabIndex = 27
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button3.Location = New System.Drawing.Point(517, 301)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 28
        Me.Button3.Text = "Save As..."
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(235, 217)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(354, 48)
        Me.Button5.TabIndex = 22
        Me.Button5.Text = "Generate Code"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button6.Location = New System.Drawing.Point(517, 271)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 26
        Me.Button6.Text = "About..."
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label6.Location = New System.Drawing.Point(10, 306)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(42, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Output:"
        '
        'donttouch
        '
        Me.donttouch.Location = New System.Drawing.Point(420, 276)
        Me.donttouch.Name = "donttouch"
        Me.donttouch.ReadOnly = True
        Me.donttouch.Size = New System.Drawing.Size(84, 18)
        Me.donttouch.TabIndex = 12
        Me.donttouch.TabStop = False
        Me.donttouch.Text = "dont touch this"
        Me.donttouch.Visible = False
        '
        'testbtn
        '
        Me.testbtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.testbtn.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.testbtn.Location = New System.Drawing.Point(90, 271)
        Me.testbtn.Name = "testbtn"
        Me.testbtn.Size = New System.Drawing.Size(75, 23)
        Me.testbtn.TabIndex = 25
        Me.testbtn.Text = "Test Code..."
        Me.testbtn.UseVisualStyleBackColor = True
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.AutoUpgradeEnabled = False
        Me.SaveFileDialog1.Filter = "VBS Script (*.vbs)|*.vbs|Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
        '
        'reset
        '
        Me.reset.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.reset.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.reset.Location = New System.Drawing.Point(174, 271)
        Me.reset.Name = "reset"
        Me.reset.Size = New System.Drawing.Size(75, 23)
        Me.reset.TabIndex = 29
        Me.reset.Text = "Reset"
        Me.reset.UseVisualStyleBackColor = True
        '
        'radioques
        '
        Me.radioques.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.radioques.Appearance = System.Windows.Forms.Appearance.Button
        Me.radioques.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.user32_1_102
        Me.radioques.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.radioques.Location = New System.Drawing.Point(6, 211)
        Me.radioques.Name = "radioques"
        Me.radioques.Size = New System.Drawing.Size(42, 42)
        Me.radioques.TabIndex = 8
        Me.radioques.TabStop = True
        Me.radioques.UseVisualStyleBackColor = True
        '
        'radioinfo
        '
        Me.radioinfo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.radioinfo.Appearance = System.Windows.Forms.Appearance.Button
        Me.radioinfo.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.user32_1_104
        Me.radioinfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.radioinfo.Location = New System.Drawing.Point(6, 163)
        Me.radioinfo.Name = "radioinfo"
        Me.radioinfo.Size = New System.Drawing.Size(42, 42)
        Me.radioinfo.TabIndex = 7
        Me.radioinfo.TabStop = True
        Me.radioinfo.UseVisualStyleBackColor = True
        '
        'radioexc
        '
        Me.radioexc.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.radioexc.Appearance = System.Windows.Forms.Appearance.Button
        Me.radioexc.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.user32_1_101
        Me.radioexc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.radioexc.Location = New System.Drawing.Point(6, 115)
        Me.radioexc.Name = "radioexc"
        Me.radioexc.Size = New System.Drawing.Size(42, 42)
        Me.radioexc.TabIndex = 6
        Me.radioexc.TabStop = True
        Me.radioexc.UseVisualStyleBackColor = True
        '
        'radiox
        '
        Me.radiox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.radiox.Appearance = System.Windows.Forms.Appearance.Button
        Me.radiox.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.user32_1_103
        Me.radiox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.radiox.Location = New System.Drawing.Point(6, 66)
        Me.radiox.Name = "radiox"
        Me.radiox.Size = New System.Drawing.Size(42, 42)
        Me.radiox.TabIndex = 5
        Me.radiox.TabStop = True
        Me.radiox.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(596, 331)
        Me.Controls.Add(Me.reset)
        Me.Controls.Add(Me.testbtn)
        Me.Controls.Add(Me.donttouch)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.outputtext)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label6)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(766, 423)
        Me.MinimumSize = New System.Drawing.Size(604, 362)
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Tag = ""
        Me.Text = "MessageBox Generator (x86)"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents textmsg As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents textttl As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents radiox As System.Windows.Forms.RadioButton
    Friend WithEvents radioexc As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents radioinfo As System.Windows.Forms.RadioButton
    Friend WithEvents radioques As System.Windows.Forms.RadioButton
    Friend WithEvents radioiconone As System.Windows.Forms.RadioButton
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents combobtnif As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents textvar As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents radiook As System.Windows.Forms.RadioButton
    Friend WithEvents radioyesnocancel As System.Windows.Forms.RadioButton
    Friend WithEvents radioyesno As System.Windows.Forms.RadioButton
    Friend WithEvents radiookcancel As System.Windows.Forms.RadioButton
    Friend WithEvents radioretryignore As System.Windows.Forms.RadioButton
    Friend WithEvents radioabort As System.Windows.Forms.RadioButton
    Friend WithEvents outputtext As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents donttouch As System.Windows.Forms.RichTextBox
    Friend WithEvents testbtn As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents reset As System.Windows.Forms.Button

End Class
